---
name: incredible-lavi
description: Design, build, and improve ambitious products and artifacts, including sites, apps, games, 3D, visual identity, presentations, and documents. Use for substantial creative work, high-fidelity reference matching, or websites and interfaces that feel generic, dated, overly dark, or unfinished.
---

# Incredible Lavi

## Research and plan before building

Read the user's intent and constraints, then identify what the audience will actually do with the result. Make a plan before implementation. For substantial work, complete the [shared plan](references/planning.md) and use the [scope and detail guide](references/detail.md) to define what finished looks like. Record the quality expected and how to check every material outcome, including the opening, later use, and the hardest meaningful case. A bounded change needs a short plan.

A short brief can name a deep benchmark. Research the relevant version, actual use, and what people value before choosing scope. Collect useful public or supplied visual evidence and turn it into specific design decisions. Follow the [reference research guide](references/reference-matching.md) for source selection and matching. Research and critique can run in parallel. Finish the shared plan before any implementation or implementation assignments. Preserve the user's constraints and permissions. An explicit quick demo has a smaller finish line.

## Make the design specific

For new or redesigned websites, apps and game interfaces, use the [screen art direction guide](references/web-art-direction.md) before choosing a theme or laying out components. Start open briefs in light or subject-led color with modern, legible upright type. Use vintage display lettering and ornamental frames when the brief calls for them. Ground a dark treatment in a requested reference, a chosen user theme, or an actual viewing need. When the complaint is aesthetic, compare compositions on real content and inspect the phone and desktop renders before accepting the direction.

Lead with the task, scene, or content. Give headings the weight their job requires. Keep useful titles, labels, facts, and instructions. Cut redundant promotion and UI copy. For substantial visual work, find references using the research guide and inspect relevant live states with REA when available. Adapt useful qualities into one design. When shaping the visual identity, hide the title and ask what the design still reveals about its subject. Revise interchangeable assets, layout, or behavior where that test exposes a problem.

Read only the guides that change the work.

- Use the [typography guide](references/typography.md) when choosing or improving type.
- Use the [game guide](references/game-development.md) for playable work. Its [FPS guide](references/fps-production.md) addresses substantial shooter design.
- Use the [3D guide](references/realistic-3d.md) to make viewed surfaces, motion, and physical details convincing at the target device and scale. Honor the chosen art direction.
- For substantial independent parts, use the [design team guide](references/design-team.md). Give implementation specialists the shared plan, relevant evidence, and a tailored assignment. Keep the first-use reviewer unbriefed.

## Build past the first convincing slice

For substantial work, [review the first working slice](references/detail.md#review-the-first-working-slice) before repeating its design across the project. Compare two treatments of the open choice that most affects the audience. Observe someone unfamiliar with the work attempt a real task unaided. Then challenge the scope against the original request and benchmark. Update the plan, fix what failed, and build the remaining material outcomes. Give later parts and difficult states their own useful content, behavior, or decisions. A larger-than-life signature should make an important part of the experience more revealing, memorable, or capable. Carry the same craft into the ordinary parts people spend time using.

Be decisive about consequential gaps. If a path repeats the same mechanic, presents indistinguishable choices, relies on placeholders, or leaves the intended action unfinished, correct the underlying design. Use the user's requested effort, model, and agent limits when the host exposes them. Let the remaining work determine the number of passes. Spend effort on the artifact and its verification.

## No early handoff

For each material outcome, check both **coverage** and **craft**. Use the actual build, render, export, or delivered file at the intended size or device. A successful execution check establishes function. Inspect what the user can see, understand, decide, or achieve for the quality check. A passing compile, demo path, or attractive opening leaves the other outcomes unchecked.

Review the integrated result against the acceptance notes. On substantial work, have a fresh reviewer exercise the weakest substantial area when delegation is available and allowed, or do a separate review yourself. Put design and functional failures back into the work. Fix the highest-impact gaps, rerun the affected cases, and continue while a material in-scope gap remains resolvable. If an actual time limit, missing capability, or dependency blocks further work, leave the affected outcome open, finish independent work, and state the missing result or evidence. Report actual scope and results briefly.
