# Original games

## Make it playable early

Use the project's engine, conventions, and asset pipeline. For a new game, choose a runtime that fits the requested platform and scope. Build an original world and mechanics from the brief and use original, supplied, or licensed assets.

In the plan, define the player's goal, signature action, and feedback. Before a substantial build, identify the full session from entry to replay and the areas, encounters, or modes that give it variety. Once the plan is ready, begin with a representative scene where the player can learn the action and reach a meaningful outcome. Use it to resolve uncertain controls, camera, and readability. Then implement the rest of the requested mechanics, content, and screens. Size the result to the brief.

For a realistic 3D game, use the [realistic 3D guide](realistic-3d.md) to choose an asset pipeline and prove close-up quality in the playable scene. Apply the same care to ordinary traversal and repeat play.

## Translate the benchmark into play

Study representative gameplay and developer material for the requested genre. Write down what the player sees and does during an ordinary encounter. Use observations to pick transferable qualities such as time to first engagement, range changes, contrast near targets, how cover creates a decision, or how inputs chain into the next action. Keep the setting, map, art, sound, writing, and other game assets original or properly licensed. Use a commercial game as a standard of craft while stating the actual scope you can verify.

For a substantial first-person shooter or a request for a larger map or stronger opponents, use the [FPS production guide](fps-production.md). It covers playable scale, encounter progression, opponent behavior, and the checks that distinguish a working arena from a complete match experience.

Test the complete input chain in one encounter. Move into cover, aim, fire under pressure, reload, disengage, and resume. Check viewmodel and camera alignment while aiming and while animating. Tune feedback as a sequence of first visible response, impact confirmation, and recovery. Use matching pose, sound, trace, and hit timing. Preserve control during movement transitions and aim interruptions.

## Make play feel intentional

Lead with play or the shortest entry the game needs. Keep the HUD for decisions the player makes during play. Teach one action in context. Establish readable silhouettes, a coherent palette, and a clear camera. Check assets at the actual in-game scale and angle. Tie movement, effects, and sound to what the player did. Keep feedback clear with audio off.

For grounded physics, give relevant objects consistent scale, weight, grip, collision, and settling behavior. Let shared rules produce different results under different conditions. Make animation, lighting, surface effects, and sound agree with the state of the world. A stylized game can use those same relationships with exaggerated timing and shapes.

Repeat an important move under two conditions that should feel different, such as slow and fast contact or movement over two relevant surfaces. Check that the response is distinct and predictable, controls stay responsive, and the scene plays smoothly when busy. Verify the behavior during play.

When play feels wrong, reproduce it before changing it. For example, a floaty jump may come from input delay, acceleration, or excess airtime. Find an observation that distinguishes the causes, tune the responsible behavior, and replay the same segment.

## Play through before handing off

- Launch the actual build in a browser or engine player. Play from the normal entry using real controls. Check that input produces feedback, the core challenge responds, each applicable success or failure state is reachable, and replay or restart clears the right state.
- Check the inputs and display sizes the brief targets. Exercise the awkward case most likely to break play, such as lost focus, a missed input, a corner collision, or restarting twice. Inspect a frame during play and check runtime errors. For performance-sensitive work, check frame pacing or input response in a representative busy scene. Fix the clearest problem and replay the affected path.
- Use a short repeatable input sequence when helpful. A build or headless test can confirm logic. Assess feel visually in the running game and exercise sound when the environment permits. State which checks ran and how to launch the game.
- For a high-fidelity FPS, inspect the ordinary spawn, a close cover angle, and a moving encounter including an aim, hit, or reload. Compare them with the chosen qualities of the reference. Fix material blockout substitutes, empty combat lanes, unclear enemy responses, and pacing issues found in the agreed scope. Replay the affected encounter. Confirm objective completion, meaningful decisions, and presentation through separate observations.
