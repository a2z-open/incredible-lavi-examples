# Typography

## Set the hierarchy

Start with the real title, explanation, controls, and data. Name the roles the design needs, such as screen title, section title, body, label, and value. Give each role a repeatable family, size, weight, line height, and tracking. Use weight and spacing to distinguish related roles. Keep menus, settings, dense views, and HUDs predictable. Let display type change size with the composition when the project calls for it. Keep the reading line comfortable for the language and width.

Default to one modern sans family for new headlines and interface text. Keep an established brand or platform face when it fits. Add a second family only for a distinct job. Use upright, single-color headline type by default. Avoid oversized bookish serifs, colored italic accent lines, and forced word stacks like the rejected Oriel treatments. An approved brand or a requested art direction can call for a different treatment.

## Choose on real content

Set the same title, body text, control, and longest plausible label or value in two candidates. Start with the narrow view, then compare at the wider target size. Inspect at the delivered sizes. Begin with the face’s native spacing. Adjust tracking optically on the actual words, particularly at the weight used in buttons and titles. Check for colliding letters, muddy counters, awkward line breaks and labels too small to scan. Keep the face whose roles read clearly together. When typography can carry the signature, give it one job grounded in the subject. A camera catalog might give focal lengths a distinct width and weight beside the images and use the same treatment in specifications.

| Role | Faces to try |
| --- | --- |
| Small labels and paragraphs | [Mozilla Text](https://github.com/mozilla/mozilla-text-type) for a sturdy sans with consistent widths across weights. |
| Dense product interfaces | [Stack Sans Text](https://stackoverflow.design/brand/typography) for compact rows and clear labels. Compare it with the platform face. |
| Product and brand with one family | [Mona Sans 2](https://github.com/github/mona-sans/releases) for different widths and optical sizes within the same typographic voice. |
| Bold, clean headlines | [Zalando Sans Expanded](https://github.com/zalando/sans) for short wide headlines. Try standard width in supporting text. |
| Interface text across scripts | [Onest](https://github.com/google/fonts/blob/main/ofl/onest/METADATA.pb) for Latin, Cyrillic, and Vietnamese text. Check the project's actual strings. |

## Fit, load, and verify

- Tune line height and measure against real paragraphs. Balance short web headings when it improves phrase breaks. Use tabular numerals where values must align, and keep numbers with their units where space allows. Check optical alignment beside icons and graphics.
- Load only licensed styles, weights, and scripts actually in use. Verify the face and weights rendered at runtime, and avoid synthetic styles where the design relies on a real weight or italic. Use a metric-compatible fallback and keep text visible while fonts load.
- Inspect a representative dense state and a prominent title or product detail at narrow and wide sizes. Test enlarged text or native scaling, long or translated content, and a failed font load when applicable. Fix clipping, collisions, weak contrast, and major layout shifts. Judge hierarchy from the rendered screen before checking automated results.

Sources — [Impeccable Typeset](https://github.com/pbakaus/impeccable/blob/main/skill/reference/typeset.md), [Hallmark Fonts](https://github.com/Nutlope/hallmark/blob/main/skills/hallmark/references/fonts.md), [Anthropic Frontend Design](https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md), [Vercel Web Interface Guidelines](https://vercel.com/design/guidelines).
