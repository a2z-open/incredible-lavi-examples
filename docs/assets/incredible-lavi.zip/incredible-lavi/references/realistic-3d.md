# Realistic 3D

Aim for a convincing frame and a convincing interaction in the running experience. Pick the closest normal viewing distance, the most demanding angle, and a representative busy state. Work from real proportions, material references, and recorded motion when available. Keep stylization the user asked for.

## Choose the pipeline around the deliverable

- Use Blender or the project's modeling pipeline for authored geometry, UVs, rigging, baked lighting and texture maps. Retain editable source and export to the runtime's suitable format. Avoid using a still render as an interactive model.
- Use Three.js or the existing browser renderer for an interactive product, scene, or browser game. For a fixed-camera sequence, consider rendered frames or video if it meets the actual interaction brief. For native or simulation-heavy games, favor the project's engine or choose Godot, Unreal, Unity, or another engine based on platform, tooling, and the required physics and lighting.
- Start with a representative playable scene or inspectable product to resolve scale, lighting, responsiveness, and performance. Then carry the proven quality through the rest of the requested experience. Replace conspicuous blockout meshes and placeholder textures before handoff. Use original, supplied, or appropriately licensed assets.

## Make geometry, light, and materials agree

- Model the silhouette, thickness, bevels, and construction details people can actually see. Give a key product or prop plausible joints, fittings, labels, and seams. Check the profile, underside, and back if the camera can reach them. Spend geometry where it changes silhouettes or shadows and texture detail where it changes the surface response.
- Use physically based materials with appropriate color, roughness, metalness, and normal maps. Choose distinct finishes at the same scale. Put dirt in sheltered seams, wear at contact points, and scratches in plausible directions. Check reflections, UV seams, and texture repetition in motion.
- Establish what emits light and where it bounces. Anchor objects with contact shadows and ground them in their environment. Use reflection and ambient light that agree with the scene, then tune exposure and the camera for legibility. Examine a bright and a shadowed face. Use postprocessing to support the photographed look and confirm it still reads without the effect.
- Give a game environment foreground, middle distance, and a believable backdrop. Use practical details specific to the space, such as how the doors open or where water drains. Make interactive surfaces and props behave the way they look. Give web product objects the same proportions and finishes across the live model, close-ups, and fallback.
- Replace prominent primitives with authored or licensed geometry at the scale people actually see. Give repeated assets meaningful variations in position, use, wear, and silhouette. Treat the viewmodel, gloves, cover edges, and materials nearest the eye as hero assets in a first-person game. Check their silhouette against both the bright and dark parts of the live scene.
- Set repeat scale in world units. Use sRGB for color textures and linear sampling for normal, roughness, and metalness data. Check whether wet and dry areas react differently as the camera turns. Inspect material seams and contact shadows at arm's length and check that the environment light matches the background.

## Prove realism under motion

- In games, tune movement and camera together. Match visible collision contacts, mass, inertia, friction, and settling to the material and action. Make animation, particles, and spatial sound agree at the moment of contact. Try the same action on two relevant surfaces or at two speeds. Fix visible clipping, foot sliding, floating objects, or feedback that arrives late.
- On the web, let users inspect intended parts from all supported angles. Test touch or pointer drag, interruption, and resize. Keep scrolling, text, and controls usable while 3D loads. Provide a same-subject fallback for unavailable rendering and a reduced-motion mode for decorative movement.
- Compare a captured close-up, a normal-use frame, and a demanding motion segment against the fidelity target. Inspect at the delivery size and watch the frame pacing on representative hardware or emulation. Profile the largest CPU, GPU, and loading costs. Use baked maps, asset compression, instancing, or distance-based detail to protect the visible quality where the user will inspect it. Recheck the rendered result after each material optimization.
- Keep captures from the real player camera and use the same camera height, target location, viewport, and gameplay state before and after a rejected visual pass. Check first-person animation and world response in motion as well as pixels. A cinematic or promotional frame omits ordinary scale, visibility, and controls.
