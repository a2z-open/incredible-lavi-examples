# Design team

## Divide outcomes

For substantial work, spawn specialists when they can own distinct outcomes and the harness supports it. Respect the user's model and count choices and actual tool limits. In Codex, when the user also invokes Lavi Swarm, follow that skill's model, count, and dependency instructions. On any host, proceed with the capabilities it exposes. If it cannot delegate, tackle the same independent outcomes in order and do a separate integrated review.

The lead owns the combined deliverable. Research specialists can work during planning. Before implementation, give every implementer the same [shared plan](planning.md) and an assignment tailored to their work. Provide the plan itself or a location each worker can access. Provide the actual relevant images, captures, or linked footage as well as annotations. If the agent tool cannot carry images, use a shared readable location or link and an exact frame description. Check that important references are viewable and pass the same direction, shared rules, and intended signature to the implementation team.

An implementation assignment includes the following.

- **Context and ownership.** Name the audience, the outcome this work supports, the plan section, the exact files or surfaces owned, and the owner of other shared parts.
- **What to build.** Describe the required states and behaviors, data or asset contracts, dependencies, and what to integrate with. State when the worker can make independent decisions and which choices need to go back to the lead.
- **Evidence and direction.** Attach or link the few frames that matter, with state, crop, or timecode and the quality each one demonstrates. State the contribution to the project's signature and how it helps the user.
- **How to prove it.** Name the real task, state, device or output, and observable acceptance check. Ask for the changed paths, inspected render or replay, and unresolved gaps in the handoff.

Give workers independent scopes. Assign one owner for shared assets, tokens, components, and data contracts. Settle dependencies or agree how parts fit before parallel edits. Share revisions with the affected agents when a decision changes. For the first-use review, start a fresh session without inherited build history or use an unfamiliar reviewer. Send only the ordinary entry point, situation, and audience goal. Collect their observations before sharing the original brief and benchmark for the scope challenge. If the reviewer already saw the plan, choose someone else for the unaided task. Follow the [first-slice review](detail.md#review-the-first-working-slice) for the solo fallback.

## Require evidence from every worker

Each agent owns a specific contribution to the signature and a check that can disprove its quality. A reference specialist passes a useful observed state to an implementer. A designer can prove a hierarchy survives long content and a narrow viewport. A gameplay specialist can show how an opponent changes the player's decisions when a route closes. A researcher can verify a material claim and trace it into the delivered chart or copy. A reviewer can reproduce a high-impact defect or exercise a difficult case and show it works.

Accept a handoff with the relevant output or exact location, realistic evidence, and any unresolved material risk. Ask the worker to improve its weakest material part and replay the check. Route findings to the owners who need them as they arise. Keep notes short. Save the acceptance status when there will be a handoff or resume.

## Check the merged result

Review the integrated artifact before accepting individual claims. When delegation is available and allowed, have a fresh reviewer exercise material later use and the hardest or weakest area before sharing worker self-assessments. Otherwise make a separate pass yourself. Use the original scope and reference qualities. Ask for an exact observation, user impact, and how to reproduce it. Fix and replay material defects across assignments. The lead confirms the full deliverable before handoff.

Sources — [Impeccable New Work](https://github.com/pbakaus/impeccable/blob/main/skill/reference/new-work.md), [Impeccable Critique](https://github.com/pbakaus/impeccable/blob/main/skill/reference/critique.md).
