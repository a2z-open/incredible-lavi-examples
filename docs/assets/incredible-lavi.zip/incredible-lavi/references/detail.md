# Scope, depth, and review

## Establish the minimum scope

Write short working notes. One line per material outcome is enough. Name the user action or decision, where it happens, what quality means there, and the check that proves it. Include real content and the intended environment. Keep the criteria stable through implementation and record why they change if evidence or the brief changes. A larger assignment can keep the notes and verification status in its existing plan so another agent or resumed session can pick up where it left off.

When a brief names a benchmark, sample the parts that explain the user's taste. For a game, inspect ordinary play and a later or repeat encounter. For a site or app, follow the reference through a meaningful decision and what happens afterward. For a publication, read a representative spread and supporting material. Compare the dimensions that matter, such as decision variety, legibility, speed, feel, or image quality. Give each relevant observation an implementation decision and evidence. Name the limitation if you cannot inspect a relevant part.

Choose coverage that delivers what the user values about the experience. Check what someone would miss even if every planned feature worked. Separate required outcomes, inferred expectations for the category, and optional expansions in your working notes. Use inferred expectations to keep the scope credible. Preserve the explicit brief when expectations conflict. In an existing artifact, record how the starting path behaves before changing it. For a new artifact, preview the central idea with real content early enough to change it.

## Define depth for the medium

| Medium | What to build and exercise |
| --- | --- |
| Sites and stores | Follow discovery through supporting detail, comparison, and the promised action. Use concrete content, meaningful differences, context for scale, and functioning destinations. Exercise a deep link, Back, refresh, and recovery when the flow depends on state. |
| Apps, tools, and dashboards | Carry representative data through the actual task, saved result, and return visit. Check realistic inputs, state changes, repeat use, and a failed or interrupted action through recovery. Check that filters, calculations, saved data, and exports agree. |
| Games and simulations | Give the opening, middle, and ending different decisions. Verify ordinary traversal, meaningful variation or consequences on replay, and the requested outcomes. Inspect input, animation, sound, and visuals during representative use. |
| 3D, graphic, and brand work | Check hero and ordinary views, small and close viewing sizes, and relevant formats. Verify proportions, lighting, material behavior, legibility, and continuity across outputs. Exercise the interaction or production use the design promises. |
| Decks, editorial, and documents | Trace the audience's decision through the full argument. Verify material claims, figures, units, permissions, and supporting evidence against sources or supplied truth. Complete requested supporting pages and appendices. Open the real export and inspect layout, legibility, links, or navigation as appropriate. |
| Data, research, and other technical deliverables | Carry inputs through analysis or operation to the actual decision or output. Verify provenance, assumptions, difficult representative cases, accuracy, and reproducibility. Check the artifact through the entry point and format people actually use. |

For unfamiliar media, map the work to its audience, purpose, material transitions, and failure cases. Prove the central claim through a real action, accurate content, or trustworthy evidence.

## Review the first working slice

Use the earliest playable, usable, or readable version with representative content. Run these checks while changes are cheap and before dependent work scales up.

1. **Compare one consequential choice.** Build two distinct treatments of the decision named in the plan. Hold the task, content, starting state, and viewing or use conditions constant. Render, play, or read each at the intended size. Judge both against the same success criterion and note the tradeoff. On a departures board, try a persistent disruption notice and an explanation in the affected row using the same cancellation. Can a passenger identify their next valid sailing and explain what changed? Choose a treatment for each materially different context if the evidence warrants it. For a tightly prescribed edit, verify the requested direction directly.
2. **Watch a first attempt.** Give an unfamiliar reviewer the normal entry point and a concrete audience goal. Say “You’re at Pier 1. Which boat can you take next?” Keep the plan, expected answer, control hints, and internal state out of their brief. Let them use ordinary controls and accessibility features. Record what they actually did, where they hesitated or inferred the wrong thing, and the answer or outcome they reached. A fresh agent can exercise the task when delegation is available. Label that evidence as a simulated first use. When working alone, attempt the task from the normal entry point with diagnostics closed and label it a familiar self-check.
3. **Challenge the scope.** After recording the attempt, share the original request and its benchmark or supplied references. Ask “What would this audience miss most in the slice, and what in the brief, reference, or task makes it matter?” Then show the plan. Check whether it already covers that experience, omits something central to the brief, or reasonably excludes an optional feature. Use the audience’s task as the yardstick when there is no named reference. Keep or revise the scope with a reason. Do the comparison yourself if independent review is unavailable.

Carry the selected treatment, material gaps, owners, and revised acceptance checks into the shared plan. Fix the observed failures and replay the task. For a first-use claim after a fix, use another unfamiliar reviewer when available. Confirm the selected treatment still works in the integrated result.

## Review in use

Make two checks against each material outcome. Coverage asks whether the intended action, content, or result is reachable. Craft asks whether someone can follow it, trust it, and use it at the quality the brief calls for. Use a screenshot, replay, inspected export, relevant measurement, or source where it can answer the question. Open later and difficult parts through normal navigation. Review the actual output before reading automated scores or interpreting proxy metrics.

Inspect across the experience early enough to change core choices. Compare ordinary work with the intended level, including long content, varied states, repetition, interrupted interactions, and the actual device where applicable. Give secondary parts a reason to exist and refine their weakest material details. Use the installed Impeccable craft-floor reference for interface work when available.

Treat an unresolved material outcome as open even when a nearby case passes. Order concrete defects by user impact, repair the important ones, and rerun the failing path and any path that depends on it. Repeat if another material gap remains. If evidence is unavailable for a specific claim, state the limitation alongside the result. Keep minor polish proportional to its effect.

Sources — [Anthropic's long-running harness study](https://www.anthropic.com/research/effective-harnesses-for-long-running-agents), [Impeccable Critique](https://github.com/pbakaus/impeccable/blob/main/skill/reference/critique.md).
