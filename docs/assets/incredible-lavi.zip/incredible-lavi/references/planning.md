# Plan before implementation

Use this workflow for a substantial build, redesign, or benchmark-led request. For focused edits, a short plan can name the outcome, intended change, and check. Keep the full plan in an existing work plan or notes accessible to the team. Present the useful decisions in concise progress updates. Continue under the brief unless an unresolved decision genuinely needs the user.

## Research the experience

Apply the [reference research guide](reference-matching.md). Pin the reference's edition, platform, mode, or date when it affects the evidence. When a terse brief names a franchise or product family, choose a representative version and experience that suit the request and state the assumption. Inventory material features and their connections, including what happens before, during, after, and on another visit or run. Read first-party descriptions to establish behavior, look at actual footage, captures, or artifacts for execution details, and consult firsthand reviews or public feedback for what people praise and dislike. Use disagreements and gaps in evidence to decide what to inspect next. Identify which parts are required, inferred from the benchmark, or optional.

Prepare a short visual reference index for the plan. Include only evidence that answers a design question. Give each item an ID, a link or shared image location, its state or frame, the detail to inspect, and the decision it supports. Ensure the eventual agents can open the material. Use one frame for a static quality and a sequence or timed clip where behavior matters. Label third-party material for reference use and track build assets separately. Preserve provenance and permissions.

## Write the shared plan

Settle these points before dispatching implementation. Put the detail where a worker will act on it.

1. **Outcome and scope.** State the audience, their primary job, target platform or format, what must ship, and significant assumptions. List important features or content across the full experience, with dependencies and meaningful variants or difficult cases. Record material choices about exclusions.
2. **Direction and evidence.** Explain what the benchmark does well, what users value, and where this work can improve. Link findings and visual references to individual decisions. Set the visual and interaction rules, original assets or content needed, and the shared signature. For screen work, pass the chosen composition and its phone adaptation to implementers. State what earns the theme and where color conveys meaning. Name the open decision most likely to change what someone can understand, feel, or do. Specify a realistic task and observable success criterion for comparing two treatments. Preserve choices the user already made. For faithful reproductions the user is authorized to request, record the specific states and scale to match.
3. **Build order and owners.** Name the shared contracts for data, layout, behavior, or asset formats. Choose the first usable slice and identify which downstream work depends on its design. Schedule the first-use and scope reviews before committing those owners to it. Identify what independent work can run in parallel, who owns shared boundaries, how results will be merged, and the dependencies that hold work back.
4. **Acceptance in use.** For each material outcome, define an observable function and craft check at the target size, device, or output. Name the paths, frames, test inputs, and reference qualities that will expose shallow work. Identify where evidence or a real dependency may constrain what can be claimed.

Ask whether an implementer who sees only this plan could explain the overall experience, identify what to build first, find the visual evidence, and tell whether the result is good enough. Resolve unclear boundaries before implementation. Update the shared plan and notify dependent owners when evidence changes a decision.

## Example translation for an arcade FPS

Outline the session from setup and first contact through a contested middle, outcome, and replay. Observe which map and equipment choices change what players do. Use ordinary gameplay frames showing scale, readable positions, and the first-person gear presentation. Use sequences for transitions, feedback, and animation. Assign original level design, gear art and feedback, opponent behavior, and integration based on observed qualities and distinct acceptance checks. For example, verify that a later objective makes a different route valuable, and that two original equipment profiles reward distinct choices while remaining readable in motion.

For a full sales site, the same method maps discovery, product detail, comparison, and the action. It ties example screen states, copy evidence, product images, and reviews to the pages and interactions a visitor will actually use.
