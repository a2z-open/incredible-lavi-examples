# Substantial first-person shooters

Use this guide for a broad FPS build or a rebuild that the user rejected for feeling small, repetitive, or easy. Match the requested mode, perspective, and quality goals. Study ordinary gameplay from the named reference. Pull out the qualities that matter to this build and implement them with original maps, models, sound, and presentation.

## Commit to the playable scope

Before polishing, sketch the full session and the connected areas that support it. Mark spawns, landmarks, routes, elevation, cover, objectives, and where a fight can start from either direction. Use representative gameplay to identify the decisions that make the benchmark feel deep. Decide which the new game will support through original rules, map, equipment, and opponents. Set initial targets for first contact, cross-map travel, and session length from the pace the brief calls for. Verify them using the real controller. Measure scale in reachable space and useful play.

For a big-map brief, build several distinct places the player can enter and fight through. Give each a purpose and a different spatial problem. An open approach could reward long sightlines, a service interior could reward quick turns, and a raised crossing could offer a vulnerable shortcut. Make alternative paths useful for different reasons. Connect them with visible landmarks, playable transitions, and reasons to revisit areas from another angle. Keep the distant backdrop clearly beyond the play boundary.

Use the blockout to test routes from opposing spawns or directions. Confirm lanes lead somewhere useful, jumps and stairs are traversable, and sightlines break where cover promises. Expand the playable world and encounter plan before spending the remaining work on props or lighting. Carry the best scene's asset, sound, and animation quality through the areas players actually use. On the web, budget the busiest moment early and use spatial culling, instancing, level of detail, or staged loading as needed.

## Make a full match change the player's decisions

Choose a mode that serves the brief. If the brief is competitive, build its scoring, spawn or respawn rules, time pressure, and win condition. Use opponents that can contest space and objectives. If the brief calls for real online matches, include a real session and verify it from separate clients. Use clearly labeled bots when building solo play or practice.

Give the opening, middle, and ending different pressures. Make routes, cover, spawn angles, objectives, and enemy roles change what the player sees or does as the match progresses. In an authored mission, place encounters in spaces with distinct approaches and purposes. In a repeatable match, let objective control and spawn flow change the important fronts. Increasing enemy count, health, or speed at the same position is a difficulty adjustment. Add a new decision wherever the brief calls for deeper play.

Break down the feature families that make the named reference feel complete. Consider moment-to-moment controls and feedback, a match's full structure, viable equipment choices, opponent or team behavior, and reasons to return. Select the families that matter to the actual brief and prove each chosen family in ordinary play. For example, prove two loadouts favor different routes or situations, or prove the next objective changes how a team controls space. A new label, room, or weapon model needs meaningful behavior to count toward that promise. State selected mode, replay scope, and online scope explicitly in the working notes.

## Build opponents that behave like opponents

Give bots a bounded model of what they can see or hear and what they last knew. Lose and reacquire targets through actual line of sight and evidence. Use warning cues, aim buildup, reaction time, bursts, and cover to give the player a readable chance to respond. Make pressure come from movement, positions, and decisions instead of permanent knowledge or perfect aim.

Give each important role an observable behavior. A defender can hold a sightline while an objective is active. A mobile opponent can break off and take another legal route when a lane is held. An exposed bot can retreat, reload from cover, or rejoin from a different angle. Change priorities when a player changes route, disengages, or starts taking the objective. Set navigation fallbacks and time limits for blocked routes so an enemy can recover on its own.

## Verify the scope before calling it finished

- **Scale.** Walk the main route and each intentional alternative with the actual player controller. Check cross-map travel time, playable interiors or elevation, route connections, and landmark visibility. Confirm the requested breadth from completed spaces and interactions.
- **Variety.** Play from the normal start to the finish and restart. Sample opening, middle, and late fights across different areas. Replay at least one encounter from a materially different approach. Record what changed in the player's decisions or the outcome, including the reason another match can play differently when replay is a goal.
- **Opponents.** Replay a direct push and a flank or retreat from the same starting state. Observe whether opponents search the last known area, reacquire after a visible cue, reposition around cover, and contest the objective as designed. Check that they neither get stuck nor shoot through blocked sightlines. Adjust one repeated or unfair response you find and replay it.
- **Feel and presentation.** Capture ordinary play in at least two distinct environments and during a contested moment. Inspect the camera, viewmodel, reload, impact, audio cues, collisions, and pacing from player height. Use REA for live browser evidence when available and useful. Otherwise capture using the available browser or engine. If the user asked for REA specifically, name any missing REA evidence. Replay with the intended input and display.

Keep verification proportional to the brief. If an important encounter is sparse, repeats the same decision, or still looks like a blockout during normal play, revise the mechanic, composition, or encounter and replay it. Resolve other material issues in the selected scope before calling it finished. Report the actual playable scope and any concrete blocker briefly.
